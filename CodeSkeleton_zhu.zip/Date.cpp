// CS1300 Fall 2020
// Author: Maggie Zhu and Tyler Huynh
// Recitation: 510- Alici Edwards
// Project 3

#include <iostream>
#include "Date.h"
using namespace std;

Date :: Date() //default
{
    for (int i=0; i<12; i++)
    {
        daysInMonth[i] = 0;
    }
}

Date :: Date(int daysInMonth1[]) //parameterized
{
    for (int i=0; i<12; i++)
    {
        daysInMonth[i] = daysInMonth1[i];
    }
}

int Date :: getDaysInMonth(int index) //returns the day ... keep in mind index will be month-1
{
    return daysInMonth[index];
}

void Date :: setDaysInMonth(int daysInMonth1[], int index) //set new day
{
    daysInMonth[index] = daysInMonth1[index];
}

int Date :: getDay() //returns day
{
    return day;
}

void Date :: setDay(int day1) //sets a new day
{
    day = day1;
}

int Date :: getMonth() //returns month
{
    return month;
}

void Date :: setMonth(int month1) //sets a new month
{
    month = month1;
}

void Date :: printDate(int daysPassed) //prints the date
{
    // add days to new days passed
    day = day + daysPassed;

    //find the number of days in the month that you are currently in
    int index = month -1;
    //int daysInMonth = daysInMonth[index];

    //if the number of days exeeds that days in that month, increment the month

    //print out the month/day/year
    cout << day << " / " << month << " / " << "1847" << endl;

}

