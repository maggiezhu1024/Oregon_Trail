// CS1300 Fall 2020
// Author: Maggie Zhu and Tyler Huynh
// Recitation: 510- Alici Edwards
// Project 3

#include <iostream>
#include "Player.h"
using namespace std;

Player :: Player() //default constructor
{
    name = "";
    dead = false;
}
        
Player :: Player(string name_1, bool dead_1) //parameterized constructor
{
    name = name_1;
    dead = dead_1;
}

string Player :: getName() //returns the name
{
    return name;
}

void Player :: setName(string name_1) //sets the name
{
    name = name_1;
}


bool Player :: getDead() //returns whether or not player has died
{
    return dead;
}
        
void Player :: setDead(bool dead_1) //sets boolean to true or false
{
    dead = dead_1;
}

bool Player :: getHealth() //returns whether or not player has died
{
    return health;
}
        
void Player :: setHealth(bool health_1) //sets boolean to true or false
{
    health = health_1;
}

void Player :: sort(string name_1, bool dead_1, Player players[])
{
    //using the parameterized constructor, create an object

    //then, create a player array of size 4 (max # of players) and place it into the correct index
}
