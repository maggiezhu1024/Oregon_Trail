// CS1300 Fall 2020
// Author: Maggie Zhu and Tyler Huynh
// Recitation: 510- Alici Edwards
// Project 3

#include <iostream>
#include "Price.h"
using namespace std;

#ifndef CURRENTSUPPLIES_H
#define CURRENTSUPPLIES_H

class CurrentSupplies
{
    private:
        int food;
        int oxen;
        int bullets;
        int wagon;
        int med_kit;

    public:
        CurrentSupplies(); //default
       
        CurrentSupplies(int food_1, int oxen_1, int bullets_1, int wagon_1, int med_kit_1); //parameterized
       
        int getFood(); //returns food inventory
       
        void setFood(int food_1); //sets food inventory
       
        int getBullets(); //returns bullet inventory
       
        void setBullets(int bullets_1); //sets bullets inventory
       
        int getWagon(); //returns wagon inventory
       
        void setWagon(int wagon_1); //sets wagon inventory
       
        int getMedKit(); //returns med kit inventory
       
        void setMedKit(int med_kit_1); //sets med kit inventory

      
        


};

#endif