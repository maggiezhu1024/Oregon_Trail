// CS1300 Fall 2020
// Author: Maggie Zhu and Tyler Huynh
// Recitation: 510- Alici Edwards
// Project 3

#include <iostream>
#include "CurrentSupplies.h"
#include "Milestones.h"
#include "Player.h"
#include "Store.h"
#include "Price.h"
#include "Date.h"
using namespace std;

#ifndef GAME_H
#define GAME_H

class Game
{
    private:
        int days;
        //player arrays, milestones, 
        Player players[5]; //include name and bool dead
        Milestones milestones[15]; //includes name and location
        CurrentSupplies currentSupplies; //current supplies object

    public:

        Game(); //default

        Game(int days1); //parameterized

        void gameStart(); //function that starts the game

        void menu(); //prints menu

        void rest();

        void continueOn();

        void store(); //when the player enter the store

        void hunt(); //called when the player chooses to hunt, includes puzzles

        void misfortunes(); 

        void raiders(); //includes puzzles

        void gameEnd(); //function when the player dies

        void statusUpdate(); //prints out the status update

        void sortMilestones(string filename, Milestones milestones[], int num_of_milestones); //store

        void sortPlayers(string leader, string player1, string player2, string player3, string player4, Player players[], int num_players); //puts players into an array
        
        void ranking(string results_file, string sorted_array[]); //sorting algorithm, ranks how long it took each player
        
        bool puzzles(int puzzle_choice); //holds all of the puzzles

};

#endif