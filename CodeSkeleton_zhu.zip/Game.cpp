// CS1300 Fall 2020
// Author: Maggie Zhu and Tyler Huynh
// Recitation: 510- Alici Edwards
// Project 3

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include "CurrentSupplies.h"
#include "Milestones.h"
#include "Player.h"
#include "Store.h"
#include "Game.h"
#include "Date.h"
using namespace std;

//split function
int split (string str, char separator, string a[], int size);

Game :: Game() //default
{
    days = 0;
}

Game :: Game(int days1) //parameterized
{
    days = days1;   
}

void Game :: gameStart() //function that starts the game
{
    //printing the game introduction
    cout << "THIS PROGRAM SIMULATES A TRIP OVER THE OREGON TRAIL FROM INDEPENDENCE," <<endl;
    cout << "MISSOURI TO OREGON CITY, OREGON IN 1847. YOURFAMILY OF FIVE WILL COVER" <<endl;
    cout << "THE 2040 MILE OREGON TRAIL IN 5-6MONTHS --- IF YOU MAKE IT ALIVE." << endl;

    /*
    1. Have the player enter the leader name
    2. Place into players array
    3. Have the player enter 4 other traveling companions
    4. Place these into the players array
    5. Set the starting balance to $1600
    6. Set starting inventory to one wagon
    7. Allow the player to choose a starting date 03/28/1847 or to choose between 03/01/1847 and 05/01/1847.
    8. Input should be month, day
    9. Based upon the start date they chose, update the date object
    10. Set days=0
    11. Call the store function to allow them to visit the store before they begin
    */
}

void Game ::  menu() //prints menu (Taking TURNS)
{
    /*
    1. Prints out a status update
        a. date
        b. miles traveled
        c. distance until next milestone
        d. food
        e. bullets
        f. cash
    2. Options: Rest, Continue, Hunt, Quit
    3. Have the player choose an option
    4. Depending on the option, call a function
    */
}

void Game :: rest()
{
    /*
    1. Add 1-3 days 
    2. Subtract 3lbs of food, per person, per day
    */
}

void Game :: continueOn()
{
    /*
    1. update inventory to subtract 3lbs of food per person
    2. update days to make 2 weeks pass
    3. update the distance by adding 70-140 miles (use rand?)
    */
}

void Game :: store() //when the player enter the store
{
    //printing out the store prompt
    cout << "YOU HAD SAVED $1600 TO SPEND FOR THE TRIP, AND YOU HAVE A" <<endl;
    cout << "WAGON. YOU WILL NEED TO SPEND THE REST OF YOUR MONEY ON THE" << endl;
    cout << "FOLLOWING ITEMS:" << endl;
    cout << endl;
    cout << "OXEN: YOU CAN SPEND $100-$200 ON YOUR TEAM. THE MORE YOU" << endl;
    cout << "SPEND, THE FASTER YOU'LL GO BECAUSE YOU'LL HAVE BETTER ANIMALS." <<endl;
    cout << endl;
    cout << "FOOD: THE MORE YOU HAVE, THE LESS CHANCE THERE IS OF GETTING SICK." <<endl;
    cout << endl;
    cout << "AMMUNITION: YOU WILL NEED BULLETS FOR ATTACKS BY ANIMALS ANDBANDITS, AND FOR HUNTING FOOD." << endl;
    cout << endl;
    cout << "MISCELLANEOUS SUPPLIES. THIS INCLUDES MEDICINE AND OTHERTHINGS YOU WILL NEED FOR SICKNESS AND EMERGENCY REPAIRS." << endl;
    cout << endl;
    cout << "YOU CAN SPEND ALL YOUR MONEY BEFORE YOU START YOUR TRIP, OR YOU" << endl;
    cout << "CAN SAVE SOME OF YOUR CASH TO SPEND AT FORTS ALONG THE WAY WHEN" << endl;
    cout << "YOU RUN LOW. HOWEVER, ITEMS COST MORE AT THE FORTS. YOU CAN ALSO" << endl;
    cout << "GO HUNTING ALONG THE WAY TO GET MORE FOOD." << endl;

    /*
    1. print out menu
    2. have the user input what they want
    3. use a switch statement to track each item
    4. in each option there are specifications
        a. oxen : must spend between $100-$200
        b. food : recommended to purchase 200lbs per person
        c. bullets
        d. misc
            i. wagons
            ii. med kits
    5. update balance
    6. update the inventory
    7. print out a bill
    */
  
}

bool Game :: puzzles(int puzzle_choice) //holds all of the puzzles
{
    bool correct = false;

    switch(puzzle_choice)
    {
        case 1: //guess the number
        {
            string guess;
            int num_guess;
            int answer = rand() % 10+1; //random number between 1 and 10

            cout << "Guess a number between 1 and 10!" << endl;
            getline(cin,guess);
            num_guess = stoi(guess);

            if (num_guess == answer)
            {
                cout << "Congrats you did it!" << endl;
                correct = true;
            }
            
            else 
            {
                cout << "Sorry, better luck next time!" << endl;
                correct = false;
            }
         }

        case 2: //riddle (age)
        {

        }

        case 3: //solve a math problem
        {

        }

    }
    return correct;
}
void Game :: hunt() //called when the player chooses to hunt, includes puzzles
{

    /*
    1. use rand function to pick animal encounter
    2. allow the user to choose yes or no to hunting
    3. if yes... if they have more than 10 bullets (successful)
    4. give a puzzle for the player to solve
    5. update the food inventory based upon the hunt
        a. rabbit - 5lbs
        b. fox - 10lbs
        c. deer - 60lbs
        d. bear - 200lbs
        e. moose - 500lbs
    6. update the ammunition based upon the animal they hunted
        a. rabbit - 10
        b. fox - 8
        c. deer - 5
        d. bear - 10
        e. moose - 12
    7. ask the player how well they would like to eat
        a. poorly - 2lbs per person
        b. moderately - 3lbs per person
        c. well - 5lbs per person
    8. update the total food after eating, if over 1000lbs, leave excess behind
    6. if no... move on
    

    */
    //1 day

    //use random function to pick an animal
    int encounter;
    encounter = rand()%102; //random number 0-101 (probabilites add up to 102 in writeup?)

    //probablity to encounter animals
    if (encounter >= 0 && encounter <= 49) //rabbit
    {
        cout << "You have encountered a rabbit!" << endl;
    }

    else if(encounter >= 50 && encounter <= 74) //fox
    {
        cout << "You have encountered a fox!" << endl;
    }

    else if(encounter >=75 && encounter <= 89) //deer
    {
        cout << "You have encountered a deer!" << endl;
    }

    else if(encounter >=90 && encounter <=96) //bear
    {
        cout << "You have encountered a bear!" << endl;
    }

    else if(encounter <=97 && encounter <= 101) //moose
    {
        cout << "You have encountered a moose!" << endl;
    }

    //prompting to hunt
    cout << "Would you like to hunt?" << endl;
    cout << "1. Yes" << endl;
    cout << "2. No " << endl;

    //user input
    string hunt_choice;
    int hunt_choice_int;
    getline(cin, hunt_choice);
    hunt_choice_int = stoi(hunt_choice);

    //hunting process
    switch(hunt_choice_int)
    {
        case 1: //yes
        {

            //you might need an object for the inventory
            if (currentSupplies.getBullets() >=10)
            {
                int puzzle_choice = rand() % 4; //picks a random number 1-3
                bool correct = false;
                correct = puzzles(puzzle_choice);

                if (correct == true)
                {
                    //total up food
                    //subtract ammo
                    //ask how they want to eat
                    //If the total food exceeds 1000 lbs., cut the food at 1000lbs. and print a message explaining they had to leave the rest of the food behind.
                }

                else
                {
                    //subtract ammo
                }
                
            }
       
        }

        case 2: //no
        {
            break;
        }
    }
}

void Game :: misfortunes() 
{
    /*
    1. Use the random function to determine whether not a misfortune has occurred (40%)
    2. Use random function to determine what misfortune has occurred (1-3)
        a. Sickness
            i. Choose at random which member get sick
            ii. Print out the sickness
            iii. If party has med kit... chances of dying is 50%
            iv. If party does not have med kit...
                A. Rest : 3 days, 30% chance of dying
                B. Press On : 70% chance of dying
            v. If the leader dies, Game Over
            vi. Print out dying message
        b. Oxen dies
            i. Print out message
            ii. Update inventory
            iii. If all oxen are dead, they cannot continue
        c. Wagon Breaks
            i. Print out message
            ii. If they have spare parts, they can continue, update inventory
            iii. If they do not have spare parts, they cannot continue
    */

}

void Game :: raiders() //includes puzzles
{
    /*
    1. Use the equation to determine probablity (values will be between 5-50)
    2. Use the random function to determine the outcome
    3. If there is a raider
        a. Print out a message
        b. Run: Lose 1 ox, 10lbs of food, 1 wagon part
        c. Attack:
            i. Call puzzle funtion
            ii. If passed, gains 50lbs of food and 50 bullets
            iii. If lost, they lose 1/4 of their cash and 50 bullets
        d. Surrender: lose 1/4 of cash
    */
}

void Game :: gameEnd() //function when the player dies
{
    /*
    1. This function is called in the following conditions
        a. They successfully reach the end
        b. Everyone dies or just the leader dies
        c. No food, oxen, wagon
    2. Write the final stats to a file called results.txt
        a. Leader name
        b. Miles traveled
        c. Food remaining
        d. Cash Remaining
    3. Write the leader name and days it took to leaderboard.txt
        a. Implement a selection sort to rank them
        b. To do this, call the ranking member function
    */
   
}

void Game :: statusUpdate()
{
    //print out the following...
        //date
        //miles traveled
        //distance until next milestone
        //food available
        //bullets available
        //balance
}

void Game :: sortMilestones(string filename, Milestones milestones[], int num_of_milestones)
{
    /*
    1. Open and the read file like usual
    2. Place the milestone name and the distance in the array of milestones objects
    */

    int index;

    //reading the file
    ifstream in_file;
    in_file.open (filename);

    string line;

    //file does not open
    if (in_file.fail())
    {
        cout << "File failed to open! " << endl;
    }

    //reading the file
    while (getline (in_file,line))
    {
        string arr[15];

        //how do you use the split function with this since it is 
        //if it is not an empty line
        if(line.length()!=0)
        {
            if (line[0]>='A' && line[0]<='Z') //if the line is a milestone name
            {
                milestones[index].setMilestoneName(line);
            }

            else 
            {
                split(line, 'm', arr , 1); //splits it so it just the num
                milestones[index].setDistance(stoi(arr[0]));
            }
            index++;
        }
    }
}

void Game :: sortPlayers(string leader, string player1, string player2, string player3, string player4, Player players[], int num_players) //puts players into an array
{
    /*
    1. Create a player object
    2. Place the name and the boolean into the player object
    3. Make an array (or vec) out of these objects
    */
}
void Game :: ranking(string results_file, string sorted_array[]) //sorting algorithm, ranks how long it took each player
{
    /*
    1. Read the leaderboard.txt 
    2. Insert the results of the leaderboard.txt file into a sorted array
    3. Using selection sort, sort out the results (least days to most days)
    4. Rewrite the sorted array to the file with days and names
    5. The least amount of days should be the top
    */
}

//split function
/*
* This function splits up a string based upon the given separator and places it into an array
* Parameters: string str, char separator, string a[], int size
* Return: number of elements in the array
*/
int split (string str, char separator, string a[], int size)
{
    int count = 0; //number of splits
    string substr;
    string word = "";

    //traversing the string to find where the delimeter is 
    for (int i=0; i<str.length(); i++)
    {
        if (str[i]!=separator)
        {
            word = word + str[i]; //making the word
        }

        else if (str[i] == separator)
        {
            a[count] = word;
            count ++; 
            word = ""; //resetting what word is
        }
    }
    if (word == "") //if the word is empty
    {
        return 0;
    }
    else if (str == "") // if there is an empty string
    {
        return 0;
    }
    else if (count >= size)  /// if the amount of words that are split is larger than size
    {
        return -1;
    }
    else  //putting the final word into the array
    {
    a[count] = word;
    count ++;
    }

    return count; //return value
}