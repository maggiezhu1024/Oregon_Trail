// CS1300 Fall 2020
// Author: Maggie Zhu and Tyler Huynh
// Recitation: 510- Alici Edwards
// Project 3

#include <iostream>
#include "CurrentSupplies.h"
#include "Milestones.h"
#include "Player.h"
#include "Store.h"
#include "Game.h"
#include "Date.h"
using namespace std;

int main()
{
    Game play; //calling constructor so the game has started

    play.menu(); //calls the menu where the game is played

    return 0;
}